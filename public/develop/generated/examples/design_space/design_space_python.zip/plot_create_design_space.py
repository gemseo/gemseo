# Copyright 2021 IRT Saint Exupéry, https://www.irt-saintexupery.com
#
# This work is licensed under a BSD 0-Clause License.
#
# Permission to use, copy, modify, and/or distribute this software
# for any purpose with or without fee is hereby granted.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL
# WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL
# THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT,
# OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING
# FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
# NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
# WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

# Contributors:
#    INITIAL AUTHORS - initial API and implementation and/or initial
#                           documentation
#        :author: Jean-Christophe Giret
#    OTHER AUTHORS   - MACROSCOPIC CHANGES
"""# DesignSpace creation and manipulation.

In this example, we will see how to create and how to manipulate an instance of
[DesignSpace][gemseo.algos.design_space.DesignSpace].
"""

from __future__ import annotations

from numpy import array

from gemseo import create_design_space

# %%
# ## Create a design space
#
#
# The user can create an instance of the [DesignSpace][gemseo.algos.design_space.DesignSpace]
# using the high-level function [create_design_space()][gemseo.create_design_space].
design_space = create_design_space()

# %%
# ## Add design variables
#
#
# The user can add new design variables using the [add_variable()][gemseo.algos.design_space.DesignSpace.add_variable].
# In the following example, we add the `x` variable in the design space. We also
# define the lower and upper bound of the variable.
# It is then possible to plot the [DesignSpace][gemseo.algos.design_space.DesignSpace] instance either using a
# print statement or by using the logger.
design_space.add_variable(
    "x", lower_bound=array([-2.0]), upper_bound=array([2.0]), value=array([0.0])
)
design_space

# %%
# The user can also add design variables with dimension greater than one. To do
# that, the user can use the `size` keyword:
design_space.add_variable(
    "y",
    lower_bound=array([-2.0, -1.0]),
    upper_bound=array([2.0, 1.0]),
    value=array([0.0, 0.0]),
    size=2,
)
design_space

# %%
# By default, each variable infers its type from the given values. One may also
# specify it with the `type_` keyword
design_space.add_variable(
    "z",
    lower_bound=array([0, -1]),
    upper_bound=array([3, 1]),
    value=array([0, 1]),
    size=2,
    type_="integer",
)
design_space

# %%
# !!! note
#
#     Some optimization algorithms may not handle integer variables properly.
#     For updated information about the optimization algorithms that handle
#     integer variables, refer to [the available optimization algorithms][available-optimization-algorithms].
#
#     For additional information on how GEMSEO handles integer variables, refer to
#     [the user guide][how-to-deal-with-design-spaces].
#
# ## Remove design variables
#
#
# The user can also remove a variable in the design space using the
# [remove_variable()][gemseo.algos.design_space.DesignSpace.remove_variable] method:
design_space.remove_variable("x")
design_space
