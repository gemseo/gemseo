# Copyright 2021 IRT Saint Exupéry, https://www.irt-saintexupery.com
#
# This work is licensed under a BSD 0-Clause License.
#
# Permission to use, copy, modify, and/or distribute this software
# for any purpose with or without fee is hereby granted.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL
# WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL
# THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT,
# OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING
# FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
# NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
# WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

# Contributors:
#    INITIAL AUTHORS - initial API and implementation and/or initial
#                           documentation
#        :author: Matthias De Lozzo
#    OTHER AUTHORS   - MACROSCOPIC CHANGES
"""# Save a scenario for post-processing."""

from __future__ import annotations

from gemseo import create_design_space
from gemseo import create_discipline
from gemseo import create_scenario
from gemseo.algos.opt.nlopt.settings.nlopt_cobyla_settings import NLOPT_COBYLA_Settings

# %%
# We consider a minimization problem over the interval $[0,1]$
# of the $f(x)=x^2$ objective function:
discipline = create_discipline("AnalyticDiscipline", expressions={"y": "x**2"})

design_space = create_design_space()
design_space.add_variable("x", lower_bound=0.0, upper_bound=1.0)

scenario = create_scenario(
    [discipline], "y", design_space, formulation_name="DisciplinaryOpt"
)

# %%
# We solve this optimization problem with the gradient-free algorithm COBYLA:
scenario.execute(NLOPT_COBYLA_Settings(max_iter=10))

# %%
# Then,
# we save the results to an HDF5 file for future post-processing:
scenario.to_hdf("my_results.hdf")

# %%
# !!! info "See also"
#
#     [Example: post-process an HDF5 file][post-process-an-hdf5-file].
