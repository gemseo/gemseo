# Copyright 2021 IRT Saint Exupéry, https://www.irt-saintexupery.com
#
# This work is licensed under a BSD 0-Clause License.
#
# Permission to use, copy, modify, and/or distribute this software
# for any purpose with or without fee is hereby granted.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL
# WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL
# THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT,
# OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING
# FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
# NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
# WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

# Contributors:
#    INITIAL AUTHORS - initial API and implementation and/or initial
#                           documentation
#        :author: Matthias De Lozzo
#    OTHER AUTHORS   - MACROSCOPIC CHANGES
"""# Boxplot."""

from __future__ import annotations

from numpy import hstack
from numpy import linspace

from gemseo.datasets.io_dataset import IODataset
from gemseo.post.dataset.boxplot import Boxplot
from gemseo.post.dataset.boxplot_settings import Boxplot_Settings

# %%
# ## Build a dataset
#
inputs = linspace(-1, 1, 100)[:, None]

dataset = IODataset(dataset_name="Foo")
dataset.add_output_variable("y1", inputs**2)
dataset.add_output_variable("y2", hstack((inputs**3, inputs**4)))

other_dataset = IODataset(dataset_name="Bar")
other_dataset.add_output_variable("y1", -(inputs**2))
other_dataset.add_output_variable("y2", hstack((-(inputs**3), -(inputs**4))))

# %%
# ## Plot y1 and y2
#
# We can use the [Boxplot][gemseo.post.dataset.boxplot.Boxplot] plot.
plot = Boxplot(dataset)
plot.xlabel = "Variables"
plot.ylabel = "Values"
plot.title = "Standard boxplots"
plot.execute(save=False, show=True)

# %%
# ## Plot with centering
#
# We can center the data:
plot = Boxplot(dataset, Boxplot_Settings(center=True))
plot.title = "With centering"
plot.execute(save=False, show=True)

# %%
# ## Plot with scaling
#
# We can scale the data (normalization with the standard deviation):
plot = Boxplot(dataset, Boxplot_Settings(scale=True))
plot.title = "With scaling"
plot.execute(save=False, show=True)

# %%
# ## Plot without outliers
#
# We can remove the outliers:
plot = Boxplot(dataset, Boxplot_Settings(add_outliers=False))
plot.title = "Without outliers"
plot.execute(save=False, show=True)

# %%
# ## Plot with confidence intervals
#
# We can add confidence intervals for the median:
plot = Boxplot(dataset, Boxplot_Settings(add_confidence_interval=True))
plot.title = "Confidence intervals"
plot.execute(save=False, show=True)

# %%
# ## Plot horizontally
#
# We can use horizontal bars:
plot = Boxplot(dataset, Boxplot_Settings(use_vertical_bars=False))
plot.title = "Horizontal bars"
plot.execute(save=False, show=True)

# %%
# ## Plot with other datasets
#
# We can add a dataset:
plot = Boxplot(dataset, Boxplot_Settings(datasets=[other_dataset]))
plot.title = "Additional dataset"
plot.execute(save=False, show=True)
