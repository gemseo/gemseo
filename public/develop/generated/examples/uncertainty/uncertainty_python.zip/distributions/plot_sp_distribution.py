# Copyright 2021 IRT Saint Exupéry, https://www.irt-saintexupery.com
#
# This work is licensed under a BSD 0-Clause License.
#
# Permission to use, copy, modify, and/or distribute this software
# for any purpose with or without fee is hereby granted.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL
# WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL
# THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT,
# OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING
# FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
# NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
# WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

# Contributors:
#    INITIAL AUTHORS - initial API and implementation and/or initial
#                           documentation
#        :author: Matthias De Lozzo
#    OTHER AUTHORS   - MACROSCOPIC CHANGES
"""# Probability distributions based on SciPy.

In this example,
we seek to create a probability distribution based on the SciPy library.
"""

from __future__ import annotations

from gemseo.uncertainty import create_distribution
from gemseo.uncertainty import get_available_distributions
from gemseo.uncertainty.distributions.scipy.distribution_settings import (
    SPDistribution_Settings,
)
from gemseo.uncertainty.distributions.scipy.normal_settings import (
    SPNormalDistribution_Settings,
)

# %%
# First of all,
# we can access the names of the available probability distributions from the API:
all_distributions = get_available_distributions()
all_distributions

# %%
# and filter the ones based on the SciPy library
# (their names start with the acronym 'SP'):
sp_distributions = get_available_distributions("SPDistribution")
sp_distributions

# %%
# ## Create a distribution
#
# Then,
# we can create a probability distribution, e.g. a normal distribution.
#
# ### Case 1: the SciPy distribution has a GEMSEO class
#
# For the standard normal distribution (mean = 0 and standard deviation = 1):
distribution_0_1 = create_distribution("SPNormalDistribution")
distribution_0_1

# %%
# For a normal with mean = 1 and standard deviation = 2:
distribution_1_2 = create_distribution("SPNormalDistribution", mu=1.0, sigma=2.0)
distribution_1_2

# %%
# Same from settings defined as a Pydantic model:
distribution_1_2 = create_distribution(
    "SPNormalDistribution", settings=SPNormalDistribution_Settings(mu=1.0, sigma=2.0)
)
distribution_1_2

# %%
# ### Case 2: the SciPy distribution has no GEMSEO class
#
# When GEMSEO does not offer a class for the SciPy distribution,
# we can use the generic GEMSEO class [SPDistribution][gemseo.uncertainty.distributions.scipy.distribution.SPDistribution]
# to create any SciPy distribution
# by setting `interfaced_distribution` to its SciPy name
# and `parameters` as a dictionary of SciPy parameter names and values
# ([see the documentation of SciPy](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.norm.html)).
distribution_1_2 = create_distribution(
    "SPDistribution",
    interfaced_distribution="norm",
    parameters={"loc": 1.0, "scale": 2.0},
)
distribution_1_2

# %%
# Same from settings defined as a Pydantic model:
distribution_1_2 = create_distribution(
    "SPDistribution",
    settings=SPDistribution_Settings(
        interfaced_distribution="norm", parameters={"loc": 1.0, "scale": 2.0}
    ),
)
distribution_1_2

# %%
# ## Plot the distribution
#
# We can plot both cumulative and probability density functions:
distribution_0_1.plot()

# %%
# ## Get statistics
#
# ### Mean
#
# We can access the mean of the distribution:
distribution_0_1.mean

# %%
# ### Standard deviation
#
# We can access the standard deviation of the distribution:
distribution_0_1.standard_deviation

# %%
# ### Numerical range
#
# We can access the range,
# i.e. the difference between the numerical minimum and maximum,
# of the distribution:
distribution_0_1.range

# %%
# ### Mathematical support
#
# We can access the range,
# i.e. the difference between the minimum and maximum,
# of the distribution:
distribution_0_1.support

# %%
# ## Evaluate CDF
#
# We can evaluate the cumulative density function:
distribution_0_1.compute_cdf(0.5)

# %%
# ## Evaluate inverse CDF
#
# We can evaluate the inverse cumulative density function,
# here the quantile at 97.5%:
distribution_0_1.compute_inverse_cdf(0.975)

# %%
# ## Generate samples
#
# We can generate 10 samples of the distribution:
distribution_0_1.compute_samples(10)
