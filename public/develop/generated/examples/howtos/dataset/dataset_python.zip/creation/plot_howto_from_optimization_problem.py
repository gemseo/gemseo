# Copyright 2021 IRT Saint Exupéry, https://www.irt-saintexupery.com
#
# This work is licensed under a BSD 0-Clause License.
#
# Permission to use, copy, modify, and/or distribute this software
# for any purpose with or without fee is hereby granted.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL
# WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL
# THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT,
# OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING
# FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
# NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
# WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

# Contributors:
#    INITIAL AUTHORS - initial API and implementation and/or initial
#                           documentation
#        :author: Matthias De Lozzo
#    OTHER AUTHORS   - MACROSCOPIC CHANGES
"""# Convert a database to a dataset

## Problem

The execution of your optimization problem has been stored in a
[Database][gemseo.core.problem.database.Database],
and you want to retrieve a [Dataset][gemseo.dataset.dataset.Dataset] from it.

## Solution

The [to_dataset()][gemseo.optimization.problem.OptimizationProblem.to_dataset]
method can be used to create a
[Dataset][gemseo.dataset.dataset.Dataset]
from the database attached to your optimization problem.

## Step-by-step guide
"""

from __future__ import annotations

from gemseo import execute_algo
from gemseo.optimization import SLSQP_Settings
from gemseo.problem.optimization.rosenbrock import Rosenbrock

# %%
# ### 1. Create and execute an optimization problem
#
# Solve the [Rosenbrock][gemseo.problem.optimization.rosenbrock.Rosenbrock] optimization problem
# with the SLSQP algorithm and 10 iterations:
optimization_problem = Rosenbrock()
execute_algo(optimization_problem, settings_model=SLSQP_Settings(max_iter=10))

# %%
# ### 2. Convert to dataset
#
# Then,
# the [Database][gemseo.core.problem.database.Database] attached to this [OptimizationProblem][gemseo.optimization.problem.OptimizationProblem]
# can be converted to an [OptimizationDataset][gemseo.dataset.optimization_dataset.OptimizationDataset]
# using the method [to_dataset()][gemseo.optimization.problem.OptimizationProblem.to_dataset]:
dataset = optimization_problem.to_dataset()
dataset

# %%
# The design variables and output variables are in separate groups.
# You can also use an [IODataset][gemseo.dataset.io_dataset.IODataset] instead of an [OptimizationDataset][gemseo.dataset.optimization_dataset.OptimizationDataset]:
dataset = optimization_problem.to_dataset(opt_naming=False)
dataset

# %%
# or simply do not separate the variables
dataset = optimization_problem.to_dataset(categorize=False)
dataset
# %%
# !!! note
#     Only design variables and functions (objective function, constraints) are
#     stored in the database. If you want to store state variables, you must add
#     them as observables before the problem is executed.
#     See [Observe variables of interest][observe-variables-of-interest] for more information.
#
# ## Summary
#
# A [Dataset][gemseo.dataset.dataset.Dataset] can be generated from a
# [Database][gemseo.core.problem.database.Database] attached to an
# [OptimizationProblem][gemseo.optimization.problem.OptimizationProblem]
# by using the [to_dataset()][gemseo.optimization.problem.OptimizationProblem.to_dataset] method.
